import { K as Kt, J as Jt, b as a, A, I as It, G as Gt, a as t, M as Mt, O as Ot, H as Ht } from '../storage-writer-d33f2334.js';
import { J as JN, V as Vn } from '../App-dd002176.js';
import { S as Sd } from '../profile-hook-264bc43e.js';
import '../csp-672ab0f6.js';

function h(t){A(t,"svelte-15b8lzk","body{height:100%;width:100%}:root{--drawer-width:256px;--app-content-width:calc(100% - 260px);--top-bar-height:48px;--top-bar-width:calc(100% - 255px)}");}function u(t$1){let s,r;return s=new JN({props:{isFullscreen:!0}}),{c(){It(s.$$.fragment);},m(t,a){Gt(s,t,a),r=!0;},p:t,i(t){r||(Mt(s.$$.fragment,t),r=!0);},o(t){Ot(s.$$.fragment,t),r=!1;},d(t){Ht(s,t);}}}function l(t){return Vn.set(!0),[]}Sd();const w=new class extends Kt{constructor(t){super(),Jt(this,t,l,u,a,{},h);}}({target:document.body});

export { w as default };
